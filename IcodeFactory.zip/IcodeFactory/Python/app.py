# IcodeFactory: Code Test

import os
import re
import datetime


def main(comma, pipe, space):
    data = []

    # Load data
    data = add_comma(data, comma)
    data = add_pipe(data, pipe)
    data = add_space(data, space)

    # gender then lastname ascending
    data_f = [item for item in data if item[2] == "Female"]
    quick_sort_arr(data_f, 0, len(data_f) - 1, 0, 1)
    data_m = [item for item in data if item[2] == "Male"]
    quick_sort_arr(data_m, 0, len(data_m) - 1, 0, 1)
    data = data_f + data_m
    display_data("gender then lastname ascending", data)
    write_data_to_file("gender then lastname ascending", data, output_file_name)

    # dateofbirth ascending
    quick_sort_arr(data, 0, len(data) - 1, 3, 1 )
    display_data("dateofbirth ascending", data)
    write_data_to_file("dateofbirth ascending", data, output_file_name)

    # lastname descending
    quick_sort_arr(data, 0, len(data) - 1, 0, -1 )
    display_data("lastname descending", data)
    write_data_to_file("lastname descending", data, output_file_name)


def load_file(file_name, base):
    file_path = os.path.join(base, file_name)
    f = open(file_path)
    data = f.read()
    return data


def add_comma(data, values):
    values_lines = values.split("\n")
    for line in values_lines:
        value_arr = re.compile(",\s").split(line)

        # Exchange Color and Date fields
        temp = value_arr[3]
        value_arr[3] = value_arr[4]
        value_arr[4] = temp

        date = value_arr[3].split("/")
        value_arr[3] = datetime.datetime(int(date[2]), int(date[0]), int(date[1]))

        data.append(value_arr)
    return data


def add_pipe(data, values):
    values_lines = values.split("\n")
    for line in values_lines:
        value_arr = re.compile("\s[\|]\s").split(line)

        # Remove third undefined character
        del value_arr[2]

        value_arr[2] = replace_gender_abbr(value_arr[2])

        # Exchange Color and Date fields
        temp = value_arr[3]
        value_arr[3] = value_arr[4]
        value_arr[4] = temp

        # Change date delimiter from - to /
        value_arr[3] = value_arr[3].replace("-", "/")

        # Change to real date
        date = value_arr[3].split("/")
        value_arr[3] = datetime.datetime(int(date[2]), int(date[0]), int(date[1]))

        data.append(value_arr)
    return data


def add_space(data, values):
    values_lines = values.split("\n")
    for line in values_lines:
        value_arr = re.compile("\s").split(line)

        # Remove third undefined character
        del value_arr[2]

        value_arr[2] = replace_gender_abbr(value_arr[2])

        # Change date delimiter from - to /
        value_arr[3] = value_arr[3].replace("-", "/")

        # Change to real date
        date = value_arr[3].split("/")
        value_arr[3] = datetime.datetime(int(date[2]), int(date[0]), int(date[1]))

        data.append(value_arr)
    return data


def replace_gender_abbr(field):
    if field == "M":
        return "Male"
    elif field == "F":
        return "Female"

    return field


def quick_sort_arr(arr, start, end, field, order):
    if start >= end:
        return

    index = partition_arr(arr, start, end, field, order)
    quick_sort_arr(arr, start, index - 1, field, order)
    quick_sort_arr(arr, index + 1, end, field, order)


def partition_arr(arr, start, end, field, order):
    pivot_index = start;
    pivot_value = arr[end][field];
    for i in range(start, end):
        if order == 1:
            if arr[i][field] < pivot_value:
                swap(arr, i, pivot_index)
                pivot_index += 1
        elif order == -1:
            if arr[i][field] > pivot_value:
                swap(arr, i, pivot_index)
                pivot_index += 1

    swap(arr, pivot_index, end)

    return pivot_index


def swap(arr, a, b):
    temp = arr[a]
    arr[a] = arr[b]
    arr[b] = temp


def display_data(title, data):
    print(title)
    print("--------------------------")
    for item in data:
        print(get_line(item))
    print("\n--------------------------\n")


def get_line(item):
    last_name = item[0].ljust(16, " ")
    first_name = item[1].ljust(16, " ")
    gender = item[2].ljust(16, " ")

    month = str(item[3].month).rjust(2, "0")
    day = str(item[3].day).rjust(2, "0")
    year = str(item[3].year)

    date_of_birth = (month + "/" + day + "/" + year).ljust(16, " ")

    favorite_color = item[4].ljust(16, " ")

    return last_name + first_name + gender + date_of_birth + favorite_color


def write_data_to_file(title, data, output_file_name):
    f = open(output_file_name, "a")

    f.write(title + "\n")
    f.write("--------------------------\n")
    for item in data:
        f.write(get_line(item) + "\n")
    f.write("\n--------------------------\n\n")

    f.close()


def delete_output_file(file_name):
    if os.path.exists(file_name):
        os.remove(file_name)


output_file_name = "output.txt"
support_files = "./SupportFiles/"

comma = load_file("comma.txt", support_files)
pipe = load_file("pipe.txt", support_files)
space = load_file("space.txt", support_files)

delete_output_file(output_file_name)

main(comma, pipe, space)
