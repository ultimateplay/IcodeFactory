let comma, pipe, space;

loadFile("comma.txt")
  .then(data => {
    comma = data;
    return loadFile("pipe.txt");
  })
  .then(data => {
    pipe = data;
    return loadFile("space.txt");
  })
  .then(data => {
    space = data;
    main(comma, pipe, space);
  });

function main(comma, pipe, space) {
  let data = [];

  // Load data
  addComma(data, comma);
  addPipe(data, pipe);
  addSpace(data, space);

  // gender then lastname ascending
  let dataF = data.filter(item => item[2] == "Female");
  quickSortArr(dataF, 0, dataF.length - 1, 0, 1);
  let dataM = data.filter(item => item[2] == "Male");
  quickSortArr(dataM, 0, dataM.length - 1, 0, 1);
  data = dataF.concat(dataM);
  DisplayData("gender then lastname ascending", data);

  // dateofbirth ascending
  quickSortArr(data, 0, data.length - 1, 3, 1);
  DisplayData("dateofbirth ascending", data);

  // lastname descending
  quickSortArr(data, 0, data.length - 1, 0, -1);
  DisplayData("lastname descending", data);
}

// ----------------------------------
//   Quick Sort for array of arrays
// ----------------------------------

function quickSortArr(arr, start, end, field, order) {
  if (start >= end) {
    return;
  }

  let index = partitionArr(arr, start, end, field, order);
  quickSortArr(arr, start, index - 1, field, order);
  quickSortArr(arr, index + 1, end, field, order);
}

function partitionArr(arr, start, end, field, order) {
  let pivotIndex = start;
  let pivotValue = arr[end][field];
  for (let i = start; i < end; i++) {
    if (order == 1) {
      if (arr[i][field] < pivotValue) {
        swap(arr, i, pivotIndex);
        pivotIndex++;
      }
    } else if (order == -1) {
      if (arr[i][field] > pivotValue) {
        swap(arr, i, pivotIndex);
        pivotIndex++;
      }
    }
  }

  swap(arr, pivotIndex, end);

  return pivotIndex;
}

function swap(arr, a, b) {
  let temp = arr[a];
  arr[a] = arr[b];
  arr[b] = temp;
}

async function loadFile(fileName) {
  const base = "SupportFiles/";
  const response = await fetch(base + fileName);
  const data = await response.text();

  return data;
}

function addComma(data, comma) {
  const comma_lines = comma.split("\n");
  comma_lines.forEach(function(line) {
    let comma_arr = line.split(/[\s,\s]+/);

    // Exchange Color and Date fields
    let temp = comma_arr[3];
    comma_arr[3] = comma_arr[4];
    comma_arr[4] = temp;

    date = comma_arr[3].split("/");
    comma_arr[3] = new Date(date[2] + "-" + date[0] + "-" + date[1]);

    data.push(comma_arr);
  });
}

function addPipe(data, pipe) {
  const pipe_lines = pipe.split("\n");
  pipe_lines.forEach(function(line) {
    let pipe_arr = line.split(/[\s|\s]+/);

    // Remove third undefined character
    pipe_arr.splice(2, 1);

    pipe_arr[2] = replaceGenderAbbr(pipe_arr[2]);

    // Exchange Color and Date fields
    let temp = pipe_arr[3];
    pipe_arr[3] = pipe_arr[4];
    pipe_arr[4] = temp;

    // Change date delimiter from - to /
    pipe_arr[3] = pipe_arr[3].replace(/-/g, "/");

    // Change to real date
    date = pipe_arr[3].split("/");
    pipe_arr[3] = new Date(date[2] + "-" + date[0] + "-" + date[1]);

    data.push(pipe_arr);
  });
}

function addSpace(data, space) {
  const space_lines = space.split("\n");
  space_lines.forEach(function(line) {
    let space_arr = line.split(/[\s]+/);

    // Remove third undefined character
    space_arr.splice(2, 1);

    space_arr[2] = replaceGenderAbbr(space_arr[2]);

    // Change date delimiter from - to /
    space_arr[3] = space_arr[3].replace(/-/g, "/");
    date = space_arr[3].split("/");
    space_arr[3] = new Date(date[2] + "-" + date[0] + "-" + date[1]);

    data.push(space_arr);
  });
}

function replaceGenderAbbr(field) {
  if (field == "M") {
    return "Male";
  } else if (field == "F") {
    return "Female";
  }

  return field;
}

function DisplayData(title, data) {
  console.log(title);
  console.log("--------------------------");

  data.forEach(function(line) {
    console.log(getLine(line));
  });

  console.log("\n--------------------------\n\n");
}

function getLine(line) {
  let lastName = line[0].padEnd(16, " ");
  let firstName = line[1].padEnd(16, " ");
  let gender = line[2].padEnd(16, " ");

  let month = (line[3].getMonth() + 1).toString().padStart(2, "0");
  let date = line[3]
    .getDate()
    .toString()
    .padStart(2, "0");
  let year = line[3].getFullYear().toString();

  dateOfBirth = (month + "/" + date + "/" + year).padEnd(16, " ");

  let favoriteColour = line[4].padEnd(16, " ");

  return lastName + firstName + gender + dateOfBirth + favoriteColour;
}
